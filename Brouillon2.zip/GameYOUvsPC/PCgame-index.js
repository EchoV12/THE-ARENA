const pEl = document.getElementById('player');
const dBar = document.getElementById('dash-bar');
const dFill = document.getElementById('dash-fill');
const bBar = document.getElementById('block-bar');
const bFill = document.getElementById('block-fill');

// Récupération de la config des touches
const kbd = localStorage.getItem('keyboardType') || 'azerty';

// État des entrées clavier
const input = { left: false, right: false, up: false, block: false };

// Physique et variables de jeu
const p = {
    x: 10, y: 50, vy: 0, 
    isJumping: false, 
    speed: 0.8, gravity: 0.6,
    // DASH
    isDashing: false, dashReady: true, dashCooldown: 2000,
    // BLOCK
    blockStamina: 100, blockCooldown: false
};

// --- GESTION DES TOUCHES ---
window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    
    // Configuration dynamique
    if (kbd === 'azerty') {
        if (k === 'q') input.left = true;
        if (k === 'd') input.right = true;
    } else {
        if (k === 'a') input.left = true;
        if (k === 'd') input.right = true;
    }

    if (k === ' ') input.up = true;
    if (k === 's' && !p.blockCooldown) input.block = true;
    if (e.key === 'Shift') performDash();
});

window.addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'q' || k === 'a') input.left = false;
    if (k === 'd') input.right = false;
    if (k === ' ') input.up = false;
    if (k === 's') { 
        input.block = false; 
        if (!p.blockCooldown) bBar.style.opacity = "0"; 
    }
});

// --- DANS LA FONCTION performDash() ---
function performDash() {

    pEl.classList.add('dashing'); // Au début du dash
// ... puis remove à la fin du setInterval

    if (!p.dashReady || p.isDashing || input.block) return;

    p.isDashing = true;
    p.dashReady = false;
    pEl.classList.add('dashing'); // Devient Blanc
    dBar.style.opacity = "1";

    let ticks = 0;
    const dashInterval = setInterval(() => {
        p.x += (input.left ? -3.5 : 3.5);
        ticks++;
        if (ticks > 8) {
            clearInterval(dashInterval);
            p.isDashing = false;
            pEl.classList.remove('dashing');
        }
    }, 16);

    

    // Recharge : la barre remonte
    let start = Date.now();
    const timer = setInterval(() => {
        let elapsed = Date.now() - start;
        let prog = (elapsed / p.dashCooldown) * 100;
        dFill.style.width = prog + "%"; // La barre se remplit

        if (prog >= 100) {
            p.dashReady = true;
            dBar.style.opacity = "0";
            clearInterval(timer);
        }
    }, 50);
}

// --- DANS LA BOUCLE update() ---
function update() {
    // Gestion visuelle du Saut
    if (p.isJumping) {
        pEl.classList.add('jumping'); // Devient Rose
    } else {
        pEl.classList.remove('jumping');
    }

    // Gestion du Blocage et de sa barre


    if (input.block && !p.blockCooldown) pEl.classList.add('blocking');
    else pEl.classList.remove('blocking');


    if (input.block && p.blockStamina > 0) {
        pEl.classList.add('blocking'); // Devient Jaune
        bBar.style.opacity = "1";
        p.blockStamina -= 1.0; // La barre descend
        bFill.style.width = p.blockStamina + "%";

        if (p.blockStamina <= 0) {
            input.block = false;
            pEl.classList.remove('blocking');
        }
    } else {
        pEl.classList.remove('blocking');
        if (p.blockStamina < 100) {
            p.blockStamina += 0.5; // La barre remonte au repos
            bFill.style.width = p.blockStamina + "%";
            bBar.style.opacity = "1";
        } else {
            bBar.style.opacity = "0";
        }
    }

    // ... reste du code de positionnement ...
    pEl.style.left = p.x + "%";
    pEl.style.bottom = p.y + "px";
    requestAnimationFrame(update);
}

// --- BOUCLE PRINCIPALE (60 FPS) ---
function update() {
    // Déplacement horizontal (autorisé pendant le saut)
    if (!input.block && !p.isDashing) {
        if (input.left && p.x > 0) p.x -= p.speed;
        if (input.right && p.x < 93) p.x += p.speed;
    }

    // Saut

    if (p.isJumping) pEl.classList.add('jumping');
else pEl.classList.remove('jumping');

    if (input.up && !p.isJumping) {
        p.isJumping = true;
        p.vy = 15;
    }
    if (p.isJumping) {
        p.y += p.vy;
        p.vy -= p.gravity;
        if (p.y <= 50) { p.y = 50; p.isJumping = false; p.vy = 0; }
    }

    // Gestion du Blocage
    if (input.block && p.blockStamina > 0) {
        bBar.style.opacity = "1";
        p.blockStamina -= 0.8;
        bFill.style.width = p.blockStamina + "%";
        pEl.style.transform = "scaleY(0.7) translateY(20px)";
        
        if (p.blockStamina <= 0) {
            input.block = false;
            p.blockCooldown = true;
            bFill.style.backgroundColor = "red";
            setTimeout(() => {
                p.blockCooldown = false;
                p.blockStamina = 100;
                bFill.style.backgroundColor = "#ffcc00";
                bBar.style.opacity = "0";
            }, 3000);
        }
    } else if (!input.block && !p.blockCooldown) {
        pEl.style.transform = "scaleY(1) translateY(0)";
        if (p.blockStamina < 100) {
            p.blockStamina += 0.3;
            bFill.style.width = p.blockStamina + "%";
            bBar.style.opacity = "1";
        } else {
            bBar.style.opacity = "0";
        }
    }

    // Mise à jour visuelle
    pEl.style.left = p.x + "%";
    pEl.style.bottom = p.y + "px";

    requestAnimationFrame(update);
}

// Lancement du jeu
update();