document.addEventListener('DOMContentLoaded', () => {
    const backBtn = document.querySelector('.back-btn');
    const pseudoDisplay = document.getElementById('display-pseudo');

    // Affiche le pseudo stocké au login
    const savedPseudo = localStorage.getItem("arena_pseudo");
    if (savedPseudo && pseudoDisplay) {
        pseudoDisplay.innerText = savedPseudo;
    }

    // Retour au MenuPlay depuis les réglages
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.location.href = "../MenuPlay/index.html"; 
        });
    }
});



function saveKeyboard(type) {
    localStorage.setItem('keyboardType', type);
    updateSelectionUI(type);
}

function updateSelectionUI(type) {
    // On remet les deux en blanc/gold de base
    document.getElementById('select-azerty').style.textShadow = "none";
    document.getElementById('select-qwerty').style.textShadow = "none";
    
    // On fait briller celui qui est sélectionné
    const activeBtn = document.getElementById('select-' + type);
    activeBtn.style.textShadow = "0 0 15px #00d9ff";
    activeBtn.style.color = "#00d9ff";
}

// Au chargement, on applique le choix précédent
document.addEventListener('DOMContentLoaded', () => {
    const saved = localStorage.getItem('keyboardType') || 'azerty';
    updateSelectionUI(saved);
});