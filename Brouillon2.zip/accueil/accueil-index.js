
document.addEventListener('DOMContentLoaded', () => {
    const startBtn = document.getElementById('start-button');
    const overlay = document.getElementById('transition-overlay');

    if (startBtn) {
        startBtn.addEventListener('click', () => {
            // 1. Déclenche le rideau noir
            overlay.classList.add('fade-out');

            // 2. Patiente 0.8s puis change de page
            setTimeout(() => {
                // ../ pour sortir de 'accueil' et aller dans 'Login'
                window.location.href = '../Login/login-index.html';
            }, 800);
        });
    } else {
        console.error("Bouton START introuvable. Vérifie l'ID dans le HTML.");
    }
    });